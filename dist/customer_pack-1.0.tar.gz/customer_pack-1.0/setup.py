
from setuptools import setup

setup(

    name="customer_pack",
    version="1.0",
    description="Constructor de la clase Customer",
    author="Johan Garcia",
    author_email="johan@gmail.com",

    packages=["customer_pack"]

)